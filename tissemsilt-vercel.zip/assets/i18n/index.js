/**
 * Index des traductions — ar / fr / en
 * Voir ./ar.js, ./fr.js, ./en.js
 */
import { ar } from './ar.js';
import { fr } from './fr.js';
import { en } from './en.js';

export const translations = { ar, fr, en };
